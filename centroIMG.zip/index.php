<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Centro de imagens</title>
</head>
<body>
    <?php
    if(isset($_POST['acao'])) {
        $arquivo = $_FILES['file'];

        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'gif'];

        if (!in_array($extensao, $permitidas)) {
            echo "Esse tipo de arquivo não é permitido.";
        } else {
            if (!is_dir('uploads')) {
                mkdir('uploads', 0755, true);
            }

            $caminhoFinal = 'uploads/' . basename($arquivo['name']);
            if (move_uploaded_file($arquivo['tmp_name'], $caminhoFinal)) {
                echo "✅ Arquivo enviado com sucesso!";
            } else {
                echo "❌ Erro ao mover o arquivo.";
            }
        }
    }
    ?>

    <form method="post" action="" enctype="multipart/form-data">
        <input type="file" name="file" required />
        <input type="submit" name="acao" value="Enviar" />
    </form>

    <div>
        <h1>Imagens enviadas</h1>
        <?php
        $imagens = glob('uploads/*.{jpg,jpeg,png,gif}', GLOB_BRACE);
        if (count($imagens) > 0) {
            foreach ($imagens as $imagem) {
                echo "<img src='$imagem' alt='Imagem' style='max-width: 200px; max-height: 200px; margin: 10px;'>";
            }
        } else {
            echo "Nenhuma imagem enviada ainda.";
        }
        ?>
    </div>
</body>
</html>
